<template>
  <p class="loading" v-show="loading">Chargement...</p>
  <p class="error" v-if="error">{{ error }}</p>

  <div v-if="country">
    <img :src="country.flags.svg" :alt="`Drapeau ${country.name.common}`" style="width: 200px;" />
    <h1>{{ country.name.common }}</h1>
    <p>Nom officiel : {{ country.name.official }}</p>
    <p>Capitale : {{ country.capital ? country.capital[0] : '—' }}</p>
    <p>Région : {{ country.region }}</p>
    <p>Population : {{ country.population.toLocaleString() }}</p>
  </div>

  <button @click="$router.back()">Retour</button>
</template>

<script>
export default {
  name: 'CountryDetailView',
  data() {
    return {
      country: null,
      loading: true,
      error: null,
      requete: 0
    }
  },
  methods: {
    async chargerPays() {
      const requete = ++this.requete
      const code = encodeURIComponent(this.$route.params.code)
      const url = `https://restcountries.conventus.de/v3.1/alpha/${code}?fields=name,capital,region,population,flags`

      this.loading = true
      this.error = null
      this.country = null
      try {
        const response = await fetch(url)
        if (!response.ok) throw new Error(`Erreur HTTP ${response.status}`)
        const data = await response.json()
        const country = Array.isArray(data) ? data[0] : data
        if (!country) throw new Error('Pays introuvable')
        if (requete === this.requete) this.country = country
      } catch {
        if (requete === this.requete) this.error = 'Impossible de charger ce pays.'
      } finally {
        if (requete === this.requete) this.loading = false
      }
    }
  },
  watch: {
    '$route.params.code': {
      immediate: true,
      handler(code) {
        if (code) this.chargerPays()
      }
    }
  }
}
</script>
