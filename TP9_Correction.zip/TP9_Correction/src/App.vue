<template>
  <div class="app">
    <header class="topbar">
      <h1>Météo en direct</h1>
      <button class="unit-toggle" @click="basculerUnite" v-if="ville">
        Afficher en {{ unite === 'metric' ? '°F' : '°C' }}
      </button>
    </header>

    <div class="search">
      <input
        v-model="query"
        @input="onInputRecherche"
        type="text"
        placeholder="Rechercher une ville... (ex: Safi, Paris, Tokyo)"
      />
      <p class="hint" v-if="chargementSuggestions">Recherche...</p>
      <p class="msg-error" v-if="erreurSuggestions">{{ erreurSuggestions }}</p>

      <ul class="suggestions" v-if="suggestions.length">
        <li v-for="s in suggestions" :key="s.lat + '-' + s.lon" @click="choisirVille(s)">
          {{ s.name }}<span v-if="s.state">, {{ s.state }}</span> ({{ s.country }})
        </li>
      </ul>
    </div>

    <div class="historique" v-if="historique.length">
      <span>Récent :</span>
      <button v-for="h in historique" :key="h.lat + '-' + h.lon" @click="choisirVille(h)">
        {{ h.name }}
      </button>
    </div>

    <div class="meteo" v-if="ville">
      <p class="loading" v-if="chargementMeteo">Chargement de la météo...</p>
      <p class="msg-error" v-else-if="erreurMeteo">{{ erreurMeteo }}</p>

      <div v-else-if="meteoActuelle" class="courante">
        <h2>{{ ville.name }}, {{ ville.country }}</h2>
        <div class="temp-actuelle">
          <img :src="iconeUrl(meteoActuelle.weather[0].icon)" :alt="meteoActuelle.weather[0].description" />
          <span class="valeur">{{ Math.round(meteoActuelle.main.temp) }}°</span>
          <span class="description">{{ meteoActuelle.weather[0].description }}</span>
        </div>
        <p class="details">
          Ressenti {{ Math.round(meteoActuelle.main.feels_like) }}° · Humidité {{ meteoActuelle.main.humidity }}%
        </p>
      </div>

      <div class="previsions" v-if="previsionsParJour.length">
        <div class="jour" v-for="j in previsionsParJour" :key="j.date">
          <span class="date">{{ j.date }}</span>
          <img :src="iconeUrl(j.icone)" :alt="j.description" />
          <span class="temps">{{ Math.round(j.min) }}° / {{ Math.round(j.max) }}°</span>
        </div>
      </div>
    </div>

    <p class="empty" v-if="!ville">Cherchez une ville pour voir sa météo.</p>
  </div>
</template>

<script>
const API_KEY = import.meta.env.VITE_OWM_API_KEY
const GEO_URL = 'https://api.openweathermap.org/geo/1.0/direct'
const WEATHER_URL = 'https://api.openweathermap.org/data/2.5/weather'
const FORECAST_URL = 'https://api.openweathermap.org/data/2.5/forecast'

const HISTORIQUE = 'tp9-historique'

async function chargerJson(url, parametres) {
  if (!API_KEY || API_KEY === 'votre_cle_ici') {
    throw new Error('Ajoutez votre clé OpenWeatherMap dans le fichier .env.')
  }

  const params = new URLSearchParams({ ...parametres, appid: API_KEY })
  const response = await fetch(`${url}?${params}`)
  if (response.status === 401) throw new Error('Clé API invalide ou encore inactive.')
  if (response.status === 429) throw new Error('Quota API dépassé. Réessayez plus tard.')
  if (!response.ok) throw new Error(`Erreur du service météo (HTTP ${response.status}).`)
  return response.json()
}

export default {
  name: 'App',
  data() {
    return {
      query: '',
      debounceTimer: null,
      rechercheId: 0,
      meteoId: 0,
      suggestions: [],
      chargementSuggestions: false,
      erreurSuggestions: null,
      ville: null,
      historique: [],
      meteoActuelle: null,
      previsions: [],
      chargementMeteo: false,
      erreurMeteo: null,
      unite: 'metric'
    }
  },
  mounted() {
    try {
      const historique = JSON.parse(localStorage.getItem(HISTORIQUE))
      if (Array.isArray(historique)) this.historique = historique.slice(0, 5)
    } catch {
      this.historique = []
    }
  },
  beforeUnmount() {
    clearTimeout(this.debounceTimer)
    this.rechercheId++
    this.meteoId++
  },
  computed: {
    previsionsParJour() {
      const jours = {}
      for (const prevision of this.previsions) {
        const [date, heure] = prevision.dt_txt.split(' ')
        const distanceMidi = Math.abs(Number(heure.slice(0, 2)) - 12)
        const { temp_min, temp_max } = prevision.main
        const jour = jours[date] ??= { date, min: temp_min, max: temp_max, distanceMidi: Infinity }
        jour.min = Math.min(jour.min, temp_min)
        jour.max = Math.max(jour.max, temp_max)
        if (distanceMidi < jour.distanceMidi) {
          jour.distanceMidi = distanceMidi
          jour.icone = prevision.weather[0].icon
          jour.description = prevision.weather[0].description
        }
      }
      return Object.values(jours)
        .sort((a, b) => a.date.localeCompare(b.date))
        .map(({ date, min, max, icone, description }) => ({ date, min, max, icone, description }))
    }
  },
  methods: {
    iconeUrl(code) {
      return `https://openweathermap.org/img/wn/${code}@2x.png`
    },
    onInputRecherche() {
      clearTimeout(this.debounceTimer)
      this.rechercheId++
      this.suggestions = []
      this.erreurSuggestions = null
      this.chargementSuggestions = false
      if (this.query.trim()) {
        this.debounceTimer = setTimeout(() => this.rechercherVilles(), 400)
      }
    },
    async rechercherVilles() {
      const id = ++this.rechercheId
      this.chargementSuggestions = true
      try {
        const villes = await chargerJson(GEO_URL, { q: this.query.trim(), limit: 5 })
        if (id !== this.rechercheId) return
        this.suggestions = villes
        if (!villes.length) this.erreurSuggestions = 'Aucune ville trouvée.'
      } catch (error) {
        if (id === this.rechercheId) this.erreurSuggestions = error.message
      } finally {
        if (id === this.rechercheId) this.chargementSuggestions = false
      }
    },
    choisirVille(ville) {
      this.query = ''
      this.onInputRecherche()
      this.ville = ville
      const anciennes = this.historique.filter(h => h.lat !== ville.lat || h.lon !== ville.lon)
      this.historique = [ville, ...anciennes].slice(0, 5)
      try {
        localStorage.setItem(HISTORIQUE, JSON.stringify(this.historique))
      } catch {
      }
      return this.chargerMeteo()
    },
    async chargerMeteo() {
      if (!this.ville) return
      const id = ++this.meteoId
      const { lat, lon } = this.ville
      const params = { lat, lon, units: this.unite, lang: 'fr' }

      this.chargementMeteo = true
      this.erreurMeteo = null
      this.meteoActuelle = null
      this.previsions = []
      try {
        const [meteo, previsions] = await Promise.all([
          chargerJson(WEATHER_URL, params),
          chargerJson(FORECAST_URL, params)
        ])
        if (id !== this.meteoId) return
        this.meteoActuelle = meteo
        this.previsions = previsions.list
      } catch (error) {
        if (id === this.meteoId) this.erreurMeteo = error.message
      } finally {
        if (id === this.meteoId) this.chargementMeteo = false
      }
    },
    basculerUnite() {
      this.unite = this.unite === 'metric' ? 'imperial' : 'metric'
      return this.chargerMeteo()
    }
  }
}
</script>
