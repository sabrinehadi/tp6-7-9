<template>
  <p class="loading" v-show="loading">Chargement...</p>
  <p class="error" v-if="error">{{ error }}</p>

  <div v-if="country">
    <img :src="country.flags.svg" :alt="`Drapeau ${country.name}`" style="width: 200px;" />
    <h1>{{ country.name }}</h1>
    <p>Nom natif : {{ country.nativeName }}</p>
    <p>Capitale : {{ country.capital || '—' }}</p>
    <p>Région : {{ country.region }}</p>
    <p>Population : {{ country.population.toLocaleString() }}</p>
  </div>

  <button @click="$router.back()">Retour</button>
</template>

<script>
export default {
  name: 'CountryDetailView',
  data() {
    return {
      country: null,
      loading: true,
      error: null
    }
  },
  methods: {
    async chargerPays() {
      this.loading = true
      this.error = null
      this.country = null
      try {
        const code = this.$route.params.code.toUpperCase()
        const reponse = await fetch('https://countries.dev/countries')
        if (!reponse.ok) throw new Error(`Erreur ${reponse.status}`)
        const donnees = await reponse.json()
        const liste = Array.isArray(donnees) ? donnees : [donnees]
        const trouve = liste.find(c => c.alpha3Code === code || c.alpha2Code === code)
        if (!trouve) throw new Error('Pays introuvable')
        this.country = trouve
      } catch (e) {
        this.error = 'Impossible de charger ce pays.'
      } finally {
        this.loading = false
      }
    }
  },
  watch: {
    '$route.params.code'(nouveau) {
      if (nouveau) this.chargerPays()
    }
  },
  mounted() {
    this.chargerPays()
  }
}
</script>
